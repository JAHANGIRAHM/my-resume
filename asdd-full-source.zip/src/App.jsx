import React from 'react';
import { Helmet } from 'react-helmet';
import { Toaster } from '@/components/ui/toaster';
import Header from '@/components/Header';
import Hero from '@/components/Hero';
import About from '@/components/About.jsx';
import Services from '@/components/Services.jsx';
import Portfolio from '@/components/Portfolio.jsx';
import Contact from '@/components/Contact.jsx';
import Footer from '@/components/Footer.jsx';

function App() {
  return (
    <>
      <Helmet>
        <title>J&BROTHERS - E-commerce, Online Services & Freelancing Experts</title>
        <meta name="description" content="Professional logo design, web design, graphic design, and freelancing services by Jahangir Ahmed. Based in Jammu & Kashmir with expertise in Java, Python, HTML, CSS, and data entry." />
      </Helmet>
      
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-indigo-900">
        <Header />
        <Hero />
        <About />
        <Services />
        <Portfolio />
        <Contact />
        <Footer />
        <Toaster />
      </div>
    </>
  );
}

export default App;