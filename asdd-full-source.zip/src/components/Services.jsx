
import React from 'react';
import { motion } from 'framer-motion';
import { Palette, Code, Smartphone, Users, Database, Briefcase } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const Services = () => {
  const { toast } = useToast();

  const services = [
    {
      icon: Palette,
      title: 'Logo Design',
      description: 'Creative and memorable logo designs that represent your brand identity perfectly.',
      features: ['Brand Identity', 'Vector Graphics', 'Multiple Formats', 'Unlimited Revisions']
    },
    {
      icon: Code,
      title: 'Web Design',
      description: 'Modern, responsive websites that deliver exceptional user experiences.',
      features: ['Responsive Design', 'SEO Optimized', 'Fast Loading', 'Mobile First']
    },
    {
      icon: Smartphone,
      title: 'Graphic Design',
      description: 'Stunning visual designs for all your marketing and branding needs.',
      features: ['Print Design', 'Digital Graphics', 'Social Media', 'Marketing Materials']
    },
    {
      icon: Users,
      title: 'Freelancing Services',
      description: 'Professional freelancing solutions tailored to your specific requirements.',
      features: ['Project Management', 'Quality Assurance', 'Timely Delivery', '24/7 Support']
    },
    {
      icon: Database,
      title: 'Data Entry',
      description: 'Accurate and efficient data entry services with attention to detail.',
      features: ['Data Processing', 'Excel Management', 'Database Creation', 'Quality Control']
    },
    {
      icon: Briefcase,
      title: 'Custom Programming',
      description: 'Custom software solutions using Java, Python, HTML, and CSS.',
      features: ['Java Applications', 'Python Scripts', 'Web Development', 'API Integration']
    }
  ];

  const handleServiceClick = (serviceName) => {
    toast({
      title: "🚧 Service Inquiry",
      description: `${serviceName} service details coming soon! Contact us for more information.`,
      duration: 3000,
    });
  };

  return (
    <section id="services" className="py-20 relative">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Our <span className="gradient-text">Services</span>
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            Comprehensive digital solutions to elevate your business and achieve your goals.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              whileHover={{ y: -10, scale: 1.02 }}
              onClick={() => handleServiceClick(service.title)}
              className="glass-effect rounded-2xl p-8 cursor-pointer group hover:shadow-2xl hover:shadow-purple-500/20 transition-all duration-300"
            >
              <div className="w-16 h-16 bg-gradient-to-r from-purple-600 to-blue-600 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                <service.icon className="text-white" size={28} />
              </div>

              <h3 className="text-xl font-bold text-white mb-4 group-hover:text-purple-300 transition-colors duration-300">
                {service.title}
              </h3>

              <p className="text-gray-400 mb-6 leading-relaxed">
                {service.description}
              </p>

              <ul className="space-y-2">
                {service.features.map((feature, featureIndex) => (
                  <li key={featureIndex} className="flex items-center text-gray-300">
                    <div className="w-2 h-2 bg-purple-500 rounded-full mr-3"></div>
                    {feature}
                  </li>
                ))}
              </ul>

              <motion.div
                whileHover={{ x: 5 }}
                className="mt-6 text-purple-400 font-semibold group-hover:text-purple-300 transition-colors duration-300"
              >
                Learn More →
              </motion.div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          viewport={{ once: true }}
          className="text-center mt-16"
        >
          <div className="glass-effect rounded-2xl p-8 max-w-4xl mx-auto">
            <h3 className="text-2xl font-bold text-white mb-4">
              Need a Custom Solution?
            </h3>
            <p className="text-gray-400 mb-6">
              We specialize in creating tailored solutions that meet your unique business requirements.
            </p>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => document.getElementById('contact').scrollIntoView({ behavior: 'smooth' })}
              className="px-8 py-4 bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-full font-semibold hover:shadow-lg hover:shadow-purple-500/25 transition-all duration-300"
            >
              Get Custom Quote
            </motion.button>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Services;
