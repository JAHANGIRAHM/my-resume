
import React from 'react';
import { motion } from 'framer-motion';
import { ExternalLink, Github } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const Portfolio = () => {
  const { toast } = useToast();

  const projects = [
    {
      title: 'E-commerce Platform',
      category: 'Web Development',
      description: 'Modern e-commerce solution with payment integration and inventory management.',
      image: 'Modern e-commerce website with shopping cart and product gallery',
      tech: ['React', 'Node.js', 'MongoDB']
    },
    {
      title: 'Brand Identity Design',
      category: 'Logo Design',
      description: 'Complete brand identity package including logo, business cards, and letterhead.',
      image: 'Professional brand identity design with logo and business materials',
      tech: ['Illustrator', 'Photoshop', 'InDesign']
    },
    {
      title: 'Mobile App UI/UX',
      category: 'App Design',
      description: 'Intuitive mobile application design with seamless user experience.',
      image: 'Modern mobile app interface design with clean UI elements',
      tech: ['Figma', 'Sketch', 'Principle']
    },
    {
      title: 'Data Analytics Dashboard',
      category: 'Web Application',
      description: 'Interactive dashboard for data visualization and business analytics.',
      image: 'Professional data analytics dashboard with charts and graphs',
      tech: ['Python', 'Django', 'Chart.js']
    },
    {
      title: 'Marketing Campaign',
      category: 'Graphic Design',
      description: 'Complete marketing campaign with social media graphics and print materials.',
      image: 'Creative marketing campaign materials and social media graphics',
      tech: ['Photoshop', 'Illustrator', 'After Effects']
    },
    {
      title: 'Corporate Website',
      category: 'Web Development',
      description: 'Professional corporate website with CMS and SEO optimization.',
      image: 'Professional corporate website with modern design and layout',
      tech: ['HTML5', 'CSS3', 'JavaScript']
    }
  ];

  const handleProjectClick = (projectTitle) => {
    toast({
      title: "🚧 Project Details",
      description: `${projectTitle} case study coming soon! Contact us for more information.`,
      duration: 3000,
    });
  };

  return (
    <section id="portfolio" className="py-20 relative">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Our <span className="gradient-text">Portfolio</span>
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            Showcasing our best work and successful projects that have helped businesses grow.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              whileHover={{ y: -10 }}
              className="glass-effect rounded-2xl overflow-hidden group cursor-pointer"
              onClick={() => handleProjectClick(project.title)}
            >
              <div className="relative overflow-hidden">
                <img  
                  className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-500"
                  alt={project.title}
                 src="https://images.unsplash.com/photo-1595872018818-97555653a011" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="absolute bottom-4 left-4 right-4 flex justify-between items-center">
                    <motion.button
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                      className="w-10 h-10 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center text-white hover:bg-white/30 transition-colors duration-300"
                    >
                      <ExternalLink size={18} />
                    </motion.button>
                    <motion.button
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                      className="w-10 h-10 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center text-white hover:bg-white/30 transition-colors duration-300"
                    >
                      <Github size={18} />
                    </motion.button>
                  </div>
                </div>
              </div>

              <div className="p-6">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-purple-400 text-sm font-medium">{project.category}</span>
                  <div className="flex space-x-1">
                    {project.tech.slice(0, 2).map((tech, techIndex) => (
                      <span key={techIndex} className="text-xs bg-purple-600/20 text-purple-300 px-2 py-1 rounded">
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>

                <h3 className="text-xl font-bold text-white mb-3 group-hover:text-purple-300 transition-colors duration-300">
                  {project.title}
                </h3>

                <p className="text-gray-400 text-sm leading-relaxed mb-4">
                  {project.description}
                </p>

                <div className="flex flex-wrap gap-2">
                  {project.tech.map((tech, techIndex) => (
                    <span key={techIndex} className="text-xs bg-gray-700/50 text-gray-300 px-2 py-1 rounded">
                      {tech}
                    </span>
                  ))}
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          viewport={{ once: true }}
          className="text-center mt-16"
        >
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => toast({
              title: "🚧 Full Portfolio",
              description: "Complete portfolio showcase coming soon! Contact us to see more projects.",
              duration: 3000,
            })}
            className="px-8 py-4 glass-effect text-white rounded-full font-semibold hover:bg-white/20 transition-all duration-300"
          >
            View All Projects
          </motion.button>
        </motion.div>
      </div>
    </section>
  );
};

export default Portfolio;
